/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  ExternalLink, 
  Globe, 
  Shield, 
  Users, 
  Map, 
  Archive, 
  Database, 
  Briefcase, 
  FileSearch,
  ArrowRight,
  Info,
  Layers
} from 'lucide-react';
import { OSINT_DATA } from './data';

const CATEGORY_ICONS: Record<string, any> = {
  "Directories & Toolkits": Layers,
  "Search Engines": Globe,
  "Archiving & Change Tracking": Archive,
  "Domains, DNS & Internet Infrastructure": Database,
  "Internet Exposure & Scanning Intelligence": Shield,
  "Threat Intel & Malware/Phishing": Shield,
  "People, Usernames & Identity": Users,
  "Social Media & Community OSINT": Users,
  "Media Verification & Forensics": FileSearch,
  "Geospatial & Mapping": Map,
  "Transportation OSINT": Globe,
  "Business & Corporate Records": Briefcase,
  "Documents & Data Discovery": FileSearch,
  "Investigation Utilities": Layers,
};

export default function App() {
  const [view, setView] = useState<'archive' | 'about'>('archive');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const categories = useMemo(() => {
    return Array.from(new Set(OSINT_DATA.map(item => item.category))).sort();
  }, []);

  const filteredData = useMemo(() => {
    return OSINT_DATA.filter(item => {
      const matchesSearch = 
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.services.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.notes.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = !selectedCategory || item.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategory]);

  const stats = useMemo(() => ({
    total: OSINT_DATA.length,
    filtered: filteredData.length,
  }), [filteredData]);

  return (
    <div className="min-h-screen bg-[#F5F2ED] text-[#1A1A1A] flex flex-col font-serif">
      {/* Header */}
      <header className="max-w-7xl mx-auto w-full px-6 pt-12 pb-8 border-b border-[#1A1A1A] flex flex-col md:flex-row md:items-end justify-between gap-8 mb-8">
        <div className="flex flex-col">
          <span className="text-[10px] uppercase tracking-[0.2em] font-sans font-bold opacity-60 mb-2">
            The Digital Intelligence Index — Vol. 01
          </span>
          <h1 
            className="text-6xl md:text-8xl font-normal leading-none tracking-tighter cursor-pointer hover:opacity-80 transition-opacity"
            onClick={() => setView('archive')}
          >
            OSINT Nexus
          </h1>
        </div>

        <div className="flex flex-col items-end w-full md:w-auto">
          {view === 'archive' && (
            <div className="relative mb-6 w-full md:w-80">
              <Search className="absolute right-0 bottom-2 w-4 h-4 opacity-30" />
              <input
                type="text"
                placeholder="SEARCH ARCHIVE..."
                className="bg-transparent border-b border-[#1A1A1A] py-2 text-[11px] tracking-widest uppercase w-full focus:outline-none placeholder:opacity-30 font-sans font-medium"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          )}
          
          <div className="flex flex-wrap justify-end gap-x-6 gap-y-2 text-[10px] tracking-[0.15em] uppercase font-sans font-bold">
            <span 
              onClick={() => { setView('archive'); setSelectedCategory(null); }}
              className={`cursor-pointer transition-all ${view === 'archive' && !selectedCategory ? 'underline underline-offset-4' : 'opacity-40 hover:opacity-100'}`}
            >
              All Entries
            </span>
            <span 
              onClick={() => setView('about')}
              className={`cursor-pointer transition-all ${view === 'about' ? 'underline underline-offset-4' : 'opacity-40 hover:opacity-100'}`}
            >
              About Nexus
            </span>
            <span className="opacity-40 hover:opacity-100 cursor-pointer transition-all">Latest</span>
          </div>
        </div>
      </header>

      {/* View Content */}
      <AnimatePresence mode="wait">
        {view === 'archive' ? (
          <motion.div 
            key="archive"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="max-w-7xl mx-auto w-full px-6 grid grid-cols-12 gap-12 flex-1 pb-20"
          >
            {/* Sidebar / Categories */}
            <aside className="col-span-12 lg:col-span-3 border-r border-[#1A1A1A]/10 pr-0 lg:pr-8 flex flex-col h-full">
              <div className="sticky top-12">
                <h2 className="text-[11px] uppercase tracking-[0.2em] font-sans font-bold mb-6 opacity-40">
                  Taxonomy / Filter
                </h2>
                <nav className="space-y-4">
                  {categories.map((category) => {
                    const Icon = CATEGORY_ICONS[category] || Layers;
                    const isActive = selectedCategory === category;
                    return (
                      <button
                        key={category}
                        onClick={() => setSelectedCategory(isActive ? null : category)}
                        className={`group w-full text-left flex items-center justify-between text-xs font-sans tracking-wide transition-all ${
                          isActive ? 'font-bold opacity-100' : 'opacity-40 hover:opacity-100'
                        }`}
                      >
                        <span className="flex items-center gap-3">
                          <Icon className="w-3.5 h-3.5 shrink-0" />
                          <span>{category}</span>
                        </span>
                        <span className="text-[10px] font-mono translate-x-2 opacity-0 group-hover:opacity-100 group-hover:translate-x-0 transition-all">
                          &bull;
                        </span>
                      </button>
                    );
                  })}
                </nav>

                <div className="mt-12 pt-8 border-t border-[#1A1A1A]/10 space-y-4">
                  <div className="flex justify-between items-baseline underline-offset-2">
                    <span className="text-[10px] font-sans font-bold uppercase tracking-widest opacity-40">Showing</span>
                    <span className="text-2xl font-normal">{stats.filtered}</span>
                  </div>
                  <div className="flex justify-between items-baseline">
                    <span className="text-[10px] font-sans font-bold uppercase tracking-widest opacity-40">Total Tools</span>
                    <span className="text-2xl font-normal">{stats.total}</span>
                  </div>
                </div>
              </div>
            </aside>

            {/* Content List Area */}
            <section className="col-span-12 lg:col-span-9 flex flex-col">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-16">
                <AnimatePresence mode="popLayout">
                  {filteredData.map((item, index) => {
                    const globalIndex = OSINT_DATA.indexOf(item) + 1;
                    return (
                      <motion.div
                        layout
                        key={item.url + item.name}
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.98 }}
                        transition={{ duration: 0.5, delay: index * 0.03, ease: [0.21, 0.47, 0.32, 0.98] }}
                        className="group flex flex-col"
                      >
                        <div className="flex items-center gap-4 mb-4">
                          <span className="text-[28px] font-normal leading-none opacity-20 group-hover:opacity-100 transition-opacity">
                            {globalIndex.toString().padStart(2, '0')}
                          </span>
                          <div className="h-[1px] flex-1 bg-[#1A1A1A]/10 group-hover:bg-[#1A1A1A]/30 transition-colors" />
                          <span className="text-[9px] font-sans font-bold uppercase tracking-[0.1em] px-2 py-1 border border-[#1A1A1A]/20">
                            {item.access}
                          </span>
                        </div>

                        <div className="mb-4">
                          <span className="text-[10px] font-sans font-bold tracking-widest uppercase opacity-40 mb-1 block">
                            {item.category}
                          </span>
                          <h3 className="text-2xl leading-tight group-hover:italic transition-all">
                            {item.name}
                          </h3>
                        </div>

                        <p className="text-sm font-sans opacity-70 leading-relaxed mb-6 line-clamp-3">
                          {item.services}
                        </p>

                        {item.notes && (
                          <div className="relative pl-6 mb-6">
                            <div className="absolute left-0 top-0 bottom-0 w-[1px] bg-[#1A1A1A]/20" />
                            <p className="text-[11px] font-sans italic opacity-60 leading-relaxed">
                              {item.notes}
                            </p>
                          </div>
                        )}

                        <div className="mt-auto pt-4 flex justify-between items-center border-t border-transparent group-hover:border-[#1A1A1A]/10 transition-colors">
                          <a 
                            href={item.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[10px] font-sans font-bold uppercase tracking-[0.2em] flex items-center gap-2 group-hover:underline underline-offset-4"
                          >
                            Launch Tool
                            <ExternalLink className="w-3 h-3" />
                          </a>
                          <ArrowRight className="w-4 h-4 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all text-[#1A1A1A]" />
                        </div>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>

              {filteredData.length === 0 && (
                <div className="flex flex-col items-center justify-center py-32 text-center border border-dashed border-[#1A1A1A]/20 rounded-lg">
                  <h3 className="text-3xl font-normal text-[#1A1A1A] mb-4">No entries found</h3>
                  <p className="text-sm font-sans opacity-50 max-w-sm mx-auto mb-8">
                    Your search for "{searchQuery}" did not yield any results in the current collection.
                  </p>
                  <button 
                    onClick={() => {setSearchQuery(''); setSelectedCategory(null);}}
                    className="text-[11px] font-sans font-bold uppercase tracking-[0.2em] border-b border-[#1A1A1A] pb-1 hover:opacity-60 transition-opacity"
                  >
                    Reset Archive Explorer
                  </button>
                </div>
              )}
            </section>
          </motion.div>
        ) : (
          <motion.div 
            key="about"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="max-w-4xl mx-auto w-full px-6 pb-20 flex-1"
          >
            <div className="grid grid-cols-1 md:grid-cols-12 gap-12 pt-8">
              <div className="md:col-span-8 space-y-12">
                <section>
                  <span className="text-[11px] font-sans font-bold uppercase tracking-widest opacity-40 mb-4 block">The Mission</span>
                  <h2 className="text-5xl font-normal leading-tight mb-6">
                    A curated archive for the modern investigator.
                  </h2>
                  <p className="text-lg leading-relaxed opacity-80 mb-6">
                    OSINT Nexus was conceived as a centralized, high-density index for Open Source Intelligence (OSINT) professionals, journalists, and cybersecurity researchers. In an era of informational fragmentation, Nexus serves as a focused lens—distilling thousands of potential tools into a curated taxonomy of high-utility resources.
                  </p>
                  <p className="text-lg leading-relaxed opacity-80">
                    Our curation philosophy prioritizes accuracy, accessibility, and relevance. Every entry in the Nexus is verified for utility in real-world investigative workflows, from basic people-search to complex geospatial analysis.
                  </p>
                </section>

                <section className="bg-[#1A1A1A] text-[#F5F2ED] p-10">
                  <span className="text-[11px] font-sans font-bold uppercase tracking-widest opacity-60 mb-6 block">User Guidelines</span>
                  <div className="space-y-8">
                    <div className="flex gap-6">
                      <span className="text-3xl font-normal opacity-30">01</span>
                      <div>
                        <h4 className="text-xl mb-2 font-bold font-sans tracking-tight">Discovery & Filtering</h4>
                        <p className="opacity-70 text-sm leading-relaxed">Use the taxonomy sidebar to isolate tools by investigative discipline. The global search bar indexes names, services, and methodology notes simultaneously.</p>
                      </div>
                    </div>
                    <div className="flex gap-6">
                      <span className="text-3xl font-normal opacity-30">02</span>
                      <div>
                        <h4 className="text-xl mb-2 font-bold font-sans tracking-tight">Ethical Integrity</h4>
                        <p className="opacity-70 text-sm leading-relaxed">OSINT activities must be conducted within legal and ethical boundaries. We advocate for the principled use of public data to unearth truth and enhance security.</p>
                      </div>
                    </div>
                    <div className="flex gap-6">
                      <span className="text-3xl font-normal opacity-30">03</span>
                      <div>
                        <h4 className="text-xl mb-2 font-bold font-sans tracking-tight">Cross-Verification</h4>
                        <p className="opacity-70 text-sm leading-relaxed">Never rely on a single primary source. Nexus provides multiple overlapping tools in most categories to facilitate robust multi-point verification.</p>
                      </div>
                    </div>
                  </div>
                </section>
              </div>

              <aside className="md:col-span-4 space-y-12">
                <div className="border-l border-[#1A1A1A]/10 pl-8 h-full">
                  <div className="mb-12">
                     <span className="text-[11px] font-sans font-bold uppercase tracking-widest opacity-40 mb-4 block">Curation Metrics</span>
                     <div className="space-y-6">
                        <div>
                          <div className="text-4xl font-normal">{stats.total}</div>
                          <div className="text-[10px] font-sans font-bold uppercase tracking-tighter opacity-50">Verified Tools</div>
                        </div>
                        <div>
                          <div className="text-4xl font-normal">14</div>
                          <div className="text-[10px] font-sans font-bold uppercase tracking-tighter opacity-50">Disciplines</div>
                        </div>
                        <div>
                          <div className="text-4xl font-normal">0.1s</div>
                          <div className="text-[10px] font-sans font-bold uppercase tracking-tighter opacity-50">Query Latency</div>
                        </div>
                     </div>
                  </div>

                  <div className="p-6 border border-[#1A1A1A]">
                    <h5 className="text-[11px] font-sans font-bold uppercase tracking-widest mb-4">Latest Updates</h5>
                    <ul className="text-xs font-sans space-y-3 opacity-60">
                      <li className="flex justify-between"><span>Database Sync</span> <span>11.MAY</span></li>
                      <li className="flex justify-between"><span>UI Reconstruction</span> <span>09.MAY</span></li>
                      <li className="flex justify-between"><span>Geo-Tool Patch</span> <span>04.MAY</span></li>
                    </ul>
                  </div>
                </div>
              </aside>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto w-full px-6 py-12 border-t border-[#1A1A1A] flex flex-col md:flex-row justify-between items-center gap-8 text-[10px] uppercase tracking-widest font-sans font-bold mt-auto">
        <div className="flex items-baseline gap-2">
          <span>VOL. 01 / NO. 142</span>
          <span className="opacity-30">|</span>
          <span className="opacity-60">Verified Intel</span>
        </div>
        
        <div className="flex gap-12">
          <span 
            onClick={() => setView('about')}
            className="cursor-pointer opacity-40 hover:opacity-100 transition-opacity italic font-serif normal-case tracking-normal text-sm"
          >
            Documentation
          </span>
          <a href="#" className="opacity-40 hover:opacity-100 transition-opacity italic font-serif normal-case tracking-normal text-sm">Contribute</a>
          <a href="#" className="opacity-40 hover:opacity-100 transition-opacity italic font-serif normal-case tracking-normal text-sm">Curation Group</a>
        </div>

        <div className="flex items-center gap-4">
          <span className="opacity-30">Last Sync: 11.MAY.26</span>
          <div className="w-2 h-2 rounded-full bg-[#1A1A1A]" />
        </div>
      </footer>
    </div>
  );
}
