# OSINT Nexus

An Open Source Intelligence (OSINT) exploration platform built with React, Vite, and Tailwind CSS.

## Features

- **Modern Tech Stack**: React 19, Vite 6, and Tailwind CSS 4.
- **AI Integration**: Prepared for Google Gemini AI integration.
- **Fast Development**: Optimized for rapid iteration and performance.
- **Responsive Design**: Mobile-first approach with fluid layouts.

## Getting Started

### Prerequisites

- Node.js (v18 or higher)
- npm or yarn

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/Slingshot202/OSINT.git
   ```
2. Navigate to the project directory:
   ```bash
   cd OSINT
   ```
3. Install dependencies:
   ```bash
   npm install
   ```

### Running Locally

To start the development server:
```bash
npm run dev
```
The app will be available at `http://localhost:3000`.

### Building for Production

To build the application for production:
```bash
npm run build
```

## Built With

- [React](https://reactjs.org/)
- [Vite](https://vitejs.dev/)
- [Tailwind CSS](https://tailwindcss.com/)
- [Google Gemini API](https://ai.google.dev/)
- [Lucide React](https://lucide.dev/)
- [Motion](https://motion.dev/)

## License

This project is licensed under the Apache-2.0 License.
