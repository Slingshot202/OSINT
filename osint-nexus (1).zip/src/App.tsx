/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Search, 
  Shield, 
  Fingerprint, 
  Globe, 
  Mail, 
  Phone, 
  Terminal, 
  Activity, 
  Database, 
  ExternalLink,
  ChevronRight,
  Menu,
  X
} from 'lucide-react';

const OSINT_MODULES = [
  { id: 'username', name: 'Username Research', icon: Fingerprint, color: 'text-blue-400' },
  { id: 'domain', name: 'Domain Analysis', icon: Globe, color: 'text-emerald-400' },
  { id: 'email', name: 'Email Investigation', icon: Mail, color: 'text-purple-400' },
  { id: 'phone', name: 'Phone Intelligence', icon: Phone, color: 'text-amber-400' },
];

const RECENT_ALERTS = [
  { id: 1, type: 'Domain', target: 'api.osint-core.net', status: 'Analysis Complete', time: '2m ago' },
  { id: 2, type: 'Username', target: 'u_shadow_99', status: 'Processing', time: '5m ago' },
  { id: 3, type: 'IP', target: '192.168.1.254', status: 'Threat Detected', time: '12m ago' },
];

export default function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeModule, setActiveModule] = useState('username');

  return (
    <div className="min-h-screen bg-[#0a0a0b] text-[#e1e2e4] font-sans selection:bg-blue-500/30">
      {/* Background Grid Pattern */}
      <div className="fixed inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />
      <div className="fixed inset-0 bg-radial-[at_50%_-20%] from-blue-500/10 via-transparent to-transparent pointer-events-none" />

      {/* Navigation Sidebar */}
      <aside 
        className={`fixed left-0 top-0 h-full bg-[#0d0d0f] border-r border-white/5 transition-all duration-300 z-50 ${isSidebarOpen ? 'w-64' : 'w-20'}`}
      >
        <div className="p-6 flex items-center justify-between border-b border-white/5">
          {isSidebarOpen && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-center gap-2 font-mono font-bold tracking-tighter"
            >
              <Shield className="w-6 h-6 text-blue-500" />
              <span className="text-xl">OSINT<span className="text-blue-500">NEXUS</span></span>
            </motion.div>
          )}
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 hover:bg-white/5 rounded-lg transition-colors ml-auto"
          >
            {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        <nav className="p-4 space-y-2 mt-4">
          <NavItem icon={Terminal} label="Dashboard" active={true} collapsed={!isSidebarOpen} />
          <NavItem icon={Activity} label="Live Feed" collapsed={!isSidebarOpen} />
          <NavItem icon={Database} label="Archives" collapsed={!isSidebarOpen} />
        </nav>
      </aside>

      {/* Main Content */}
      <main className={`transition-all duration-300 pt-8 px-8 pb-12 ${isSidebarOpen ? 'ml-64' : 'ml-20'}`}>
        <div className="max-w-6xl mx-auto space-y-12">
          
          {/* Hero / Search Section */}
          <section className="text-center space-y-8 pt-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="space-y-4"
            >
              <h1 className="text-5xl md:text-6xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-b from-white to-white/40">
                Network Intelligence.
              </h1>
              <p className="text-lg text-white/40 max-w-2xl mx-auto font-medium">
                Comprehensive data harvesting and entity analysis across public repositories, social layers, and web infrastructure.
              </p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="relative max-w-2xl mx-auto group"
            >
              <div className="absolute inset-0 bg-blue-500/20 blur-3xl opacity-20 group-hover:opacity-40 transition-opacity" />
              <div className="relative bg-[#121215] border border-white/10 rounded-2xl p-2 flex flex-col md:flex-row items-center gap-2 shadow-2xl">
                <div className="flex-1 w-full px-4 flex items-center gap-3 border-b md:border-b-0 md:border-r border-white/5 pb-2 md:pb-0">
                  <Search className="w-5 h-5 text-white/20" />
                  <input 
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Enter entity hash, username, or artifact..."
                    className="bg-transparent border-none focus:ring-0 w-full py-3 text-lg placeholder:text-white/10 outline-none"
                  />
                </div>
                <div className="flex gap-2 p-1">
                  {OSINT_MODULES.map((module) => (
                    <button
                      key={module.id}
                      onClick={() => setActiveModule(module.id)}
                      className={`p-3 rounded-xl transition-all ${activeModule === module.id ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'hover:bg-white/5 text-white/40'}`}
                      title={module.name}
                    >
                      <module.icon className="w-5 h-5" />
                    </button>
                  ))}
                </div>
                <button className="bg-blue-600 hover:bg-blue-500 text-white px-8 py-3 rounded-xl font-semibold transition-all shadow-lg shadow-blue-500/20 active:scale-95 ml-2">
                  Execute Scan
                </button>
              </div>
            </motion.div>
          </section>

          {/* Module Grid */}
          <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {OSINT_MODULES.map((module, idx) => (
              <motion.div
                key={module.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + (idx * 0.1) }}
                className="group relative p-6 bg-[#0d0d0f] border border-white/5 rounded-2xl hover:border-white/10 transition-all cursor-pointer overflow-hidden"
              >
                <div className={`absolute top-0 right-0 w-32 h-32 bg-radial-[at_100%_0%] from-blue-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity`} />
                <module.icon className={`w-8 h-8 mb-4 ${module.color}`} />
                <h3 className="font-semibold text-lg mb-2">{module.name}</h3>
                <p className="text-sm text-white/40 mb-4 line-clamp-2">Gather intelligence and link analysis for specific {module.id} targets.</p>
                <div className="flex items-center text-xs font-mono text-white/20 group-hover:text-white/60 transition-colors uppercase tracking-widest gap-1">
                  Launch Process <ChevronRight className="w-3 h-3" />
                </div>
              </motion.div>
            ))}
          </section>

          {/* Activity Feed */}
          <section className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-4">
              <div className="flex items-center justify-between px-2">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  <Activity className="w-5 h-5 text-blue-500" /> Recent Operations
                </h2>
                <button className="text-sm text-white/40 hover:text-white transition-colors">Clear Logs</button>
              </div>
              <div className="bg-[#0d0d0f] border border-white/5 rounded-2xl overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-white/2">
                    <tr className="border-b border-white/5">
                      <th className="p-4 text-xs font-mono text-white/20 uppercase tracking-widest">Type</th>
                      <th className="p-4 text-xs font-mono text-white/20 uppercase tracking-widest">Target</th>
                      <th className="p-4 text-xs font-mono text-white/20 uppercase tracking-widest">Status</th>
                      <th className="p-4 text-xs font-mono text-white/20 uppercase tracking-widest">Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    {RECENT_ALERTS.map((alert) => (
                      <tr key={alert.id} className="border-b border-white/5 hover:bg-white/2 transition-colors cursor-pointer group">
                        <td className="p-4 font-mono text-sm text-white/60">{alert.type}</td>
                        <td className="p-4 font-medium">{alert.target}</td>
                        <td className="p-4">
                          <span className={`text-xs px-2 py-1 rounded-full ${alert.status.includes('Detected') ? 'bg-red-500/10 text-red-400' : 'bg-blue-500/10 text-blue-400'}`}>
                            {alert.status}
                          </span>
                        </td>
                        <td className="p-4 text-sm text-white/20 font-mono group-hover:text-white/60 transition-colors">{alert.time}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="space-y-4">
              <h2 className="text-xl font-bold px-2">System Status</h2>
              <div className="bg-[#0d0d0f] border border-white/5 rounded-2xl p-6 space-y-6">
                <StatusItem label="Database Latency" value="14ms" status="healthy" />
                <StatusItem label="API Node Connectivity" value="99.9%" status="healthy" />
                <StatusItem label="Active Crawlers" value="2,481" status="warning" />
                <div className="pt-4 border-t border-white/5">
                  <button className="w-full py-3 bg-white/5 hover:bg-white/10 rounded-xl text-sm font-semibold transition-all flex items-center justify-center gap-2">
                    Documentation <ExternalLink className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </section>

        </div>
      </main>
    </div>
  );
}

function NavItem({ icon: Icon, label, active = false, collapsed = false }: { icon: any, label: string, active?: boolean, collapsed?: boolean }) {
  return (
    <button className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all group ${active ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'hover:bg-white/5 text-white/40 hover:text-white/80'}`}>
      <Icon className="w-5 h-5 transition-transform group-hover:scale-110" />
      {!collapsed && <span className="font-medium text-sm">{label}</span>}
      {active && !collapsed && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-blue-500" />}
    </button>
  );
}

function StatusItem({ label, value, status }: { label: string, value: string, status: 'healthy' | 'warning' | 'error' }) {
  const statusColors = {
    healthy: 'bg-emerald-500',
    warning: 'bg-amber-500',
    error: 'bg-red-500'
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-xs uppercase tracking-widest text-white/20 font-mono">
        <span>{label}</span>
        <div className={`w-1.5 h-1.5 rounded-full ${statusColors[status]} shadow-[0_0_8px_rgba(0,0,0,0.5)]`} />
      </div>
      <div className="text-xl font-mono font-medium">{value}</div>
    </div>
  );
}
